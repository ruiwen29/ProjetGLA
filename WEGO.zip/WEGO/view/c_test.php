<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Test</title>
	<link rel="stylesheet" type="text/css" href="style/style.css" />
	<link rel="icon" href="../style/logo.ico" type="image/x-icon">
	<link rel="shortcut icon" href="../style/logo.ico" type="image/x-icon">
</head>
<body>
<?php
$fichier =  "../Cartes/Carte.xml";
$xml = file_get_contents($fichier);

//echo $xml;

// $xml= "<xml><appid>123456</appid></xml>";//XML文件

$objectxml = simplexml_load_string($xml);//将文件转换成 对象
$xmljson= json_encode($objectxml );//将对象转换个JSON
$xmlarray=json_decode($xmljson,true);//将json转换成数组

// print_r($xmljson);
print_r ($xmlarray);
?>
</body>

</html>